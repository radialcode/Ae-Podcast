window.addEventListener('scroll', function () {
	const $navbar = document.getElementById('header-fixed-container');
	const $navbarPlaceholder = document.getElementById('navbar-placeholder');

	if (window.pageYOffset > 74) {
		$navbar.classList.add('header-fixed-container');
		$navbarPlaceholder.style.display = 'block';
		$navbarPlaceholder.style.height = $navbar.clientHeight + 'px';
	} else {
		$navbarPlaceholder.style.display = 'none';
		$navbar.classList.remove('header-fixed-container');
	}
});

const data = {
	crypto: [
		{ name: "BTC", price: 63689.50, fiveDaysPercentageChange: 2.01 },
		{ name: "ETH", price: 3557.13, fiveDaysPercentageChange: 3.53 },
		{ name: "BNB", price: 396.03, fiveDaysPercentageChange: 3.00 },
		{ name: "SOL", price: 135.1, fiveDaysPercentageChange: 21.27 },
	],
	stocks: [
		{ name: "APPL", price: 170.12, fiveDaysPercentageChange: -6.79 },
		{ name: "SOFI", price: 7.27, fiveDaysPercentageChange: -15.27 },
		{ name: "NVDA", price: 859.64, fiveDaysPercentageChange: 10.75 },
		{ name: "MSFT", price: 402.65, fiveDaysPercentageChange: 2.96 },
	],
	forex: [
		{ name: "EUR/USD", price: 1.0854, fiveDaysPercentageChange: -0.01 },
		{ name: "USD/JPY", price: 150.07, fiveDaysPercentageChange: 0.02 },
		{ name: "GBP/USD", price: 1.2701, fiveDaysPercentageChange: -0.03 },
		{ name: "AUD/CAD", price: 0.8837, fiveDaysPercentageChange: -0.05 },
	],
	commodities: [
		{ name: "Gold", price: 2136.40, fiveDaysPercentageChange: 0.00 },
		{ name: "Crude Oil", price: 78.24, fiveDaysPercentageChange: 0.09 },
		{ name: "Natural Gas ", price: 1.94, fiveDaysPercentageChange: 0.11 },
		{ name: "Coffee", price: 195.80, fiveDaysPercentageChange: 3.80 },
	],
	indices: [
		{ name: "Dow Jones", price: 38585.19, fiveDaysPercentageChange: -0.99 },
		{ name: "NASDAQ", price: 15939.59, fiveDaysPercentageChange: -1.65 },
		{ name: "S&P 500", price: 5086.03, fiveDaysPercentageChange: -1.02 },
		{ name: "DAX", price: 17698.40, fiveDaysPercentageChange: 0.73 },
	]
};

function getClassNameByAssetDirection(percentage) {
	if (percentage < 0) return 'down';
	if (percentage > 0) return 'up';
	return 'straight';
}

function formatPercentage(percentage) {
	const formattedNumber = percentage.toString().replace(/^-/, '');
	return parseFloat(formattedNumber);
}

const generateAsset = (name, price, percentage) => {
	return `<div class="d-flex flex-nowrap gap-1"><span>${name}</span><span class="asset-direction-${getClassNameByAssetDirection(percentage)}">${price}$</span><span class="d-flex align-items-center asset-direction-${getClassNameByAssetDirection(percentage)}"><svg width="16px" height="16px" viewBox="0 0 18 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:sketch="http://www.bohemiancoding.com/sketch/ns"><title>icon/18/icon-triangle</title><desc>Created with Sketch.</desc><defs></defs><g id="out" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" sketch:type="MSPage"><path d="M4,7 L9,13 L14,7 L4,7 L4,7 Z" id="path" fill="#000000" sketch:type="MSShapeGroup"></path></g></svg>${formatPercentage(percentage)}%</span></div>`
}

const generateAssets = () => {
	let html = '';

	for (const category in data) {
		data[category].forEach(asset => {
			html += generateAsset(asset.name, asset.price, asset.fiveDaysPercentageChange);
		});
	}

	return html;
};

const animationDuration = 20;
const delay = 2;

const contentWrapper = `<div class="horizontal-autoscroll-content d-flex align-items-center h-100 flex-nowrap text-nowrap gap-3">${generateAssets()}</div>`

document.addEventListener('DOMContentLoaded', () => {
	const assetsContainer = document.getElementById('horizontal-autoscroll-container');
	assetsContainer.innerHTML = contentWrapper + contentWrapper;
})
