document.addEventListener("DOMContentLoaded", function () {
	const button = document.getElementById("scroll-to-top-button");
	let isScrollingUp = false;
	let lastScrollTop = 0;

	button.addEventListener("click", function () {
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	});

	window.addEventListener("scroll", function () {
		const currentScrollTop = window.pageYOffset || document.documentElement.scrollTop;

		if ((window.innerWidth < 992 && isScrollingUp && currentScrollTop >= 500) || (window.innerWidth >= 992 && currentScrollTop >= 500)) {
			button.classList.add("show");
			button.disabled = false;
		} else {
			button.classList.remove("show");
			button.disabled = true;
		}

		isScrollingUp = currentScrollTop < lastScrollTop;
		lastScrollTop = currentScrollTop <= 0 ? 0 : currentScrollTop;
	});
});
