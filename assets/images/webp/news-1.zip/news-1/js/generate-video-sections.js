const fs = require('fs');

const data = [
	{
		id: "1",
		title: "Big Buck Bunny",
		thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Big_Buck_Bunny_thumbnail_vlc.png/1200px-Big_Buck_Bunny_thumbnail_vlc.png",
		duration: "8:18",
		uploadTime: "May 9, 2011",
		views: "24,969,123",
		author: "Vlc Media Player",
		videoUrl: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
		description: "Big Buck Bunny tells the story of a giant rabbit with a heart bigger than himself. When one sunny day three rodents rudely harass him, something snaps... and the rabbit ain't no bunny anymore! In the typical cartoon tradition he prepares the nasty rodents a comical revenge.\n\nLicensed under the Creative Commons Attribution license\nhttp://www.bigbuckbunny.org",
		subscriber: "25254545 Subscribers",
		isLive: true
	},
	{
		id: "2",
		title: "The first Blender Open Movie from 2006",
		thumbnailUrl: "https://i.ytimg.com/vi_webp/gWw23EYM9VM/maxresdefault.webp",
		duration: "12:18",
		uploadTime: "May 9, 2011",
		views: "24,969,123",
		author: "Blender Inc.",
		videoUrl: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
		description: "Song : Raja Raja Kareja Mein Samaja\nAlbum : Raja Kareja Mein Samaja\nArtist : Radhe Shyam Rasia\nSinger : Radhe Shyam Rasia\nMusic Director : Sohan Lal, Dinesh Kumar\nLyricist : Vinay Bihari, Shailesh Sagar, Parmeshwar Premi\nMusic Label : T-Series",
		subscriber: "25254545 Subscribers",
		isLive: true
	},
	{
		id: "3",
		title: "For Bigger Blazes",
		thumbnailUrl: "https://i.ytimg.com/vi/Dr9C2oswZfA/maxresdefault.jpg",
		duration: "8:18",
		uploadTime: "May 9, 2011",
		views: "24,969,123",
		author: "T-Series Regional",
		videoUrl: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
		description: "Song : Raja Raja Kareja Mein Samaja\nAlbum : Raja Kareja Mein Samaja\nArtist : Radhe Shyam Rasia\nSinger : Radhe Shyam Rasia\nMusic Director : Sohan Lal, Dinesh Kumar\nLyricist : Vinay Bihari, Shailesh Sagar, Parmeshwar Premi\nMusic Label : T-Series",
		subscriber: "25254545 Subscribers",
		isLive: true
	}
]

const generateHtml = (title, description, thumbnailUrl, videoUrl) => {
	return `<section class="video-section mt-5">
				<h2>${title}</h2>
				<div class="mt-3">
					<video controls class="video rounded w-100" poster="${thumbnailUrl}">
						<source
							src="${videoUrl}">
					</video>
				</div>
				<p class="mt-2 mb-0 lh-175">
					${description}
				</p>
			</section>`
}

const writeObjectToFile = (str, fileName) => {
	fs.appendFile(fileName, str + '\n', (err) => {
		if (err) {
			return err
		}
	});
}

data.forEach((el) => {
	const genStr = generateHtml(el.title, el.description, el.thumbnailUrl, el.videoUrl)
	writeObjectToFile(genStr, 'genereted-video-sections.html')
}) 